import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { data } from './data';
import { PageService, SortService, GridModule, ReorderService, PageSettingsModel, LazyLoadGroupService, GroupService, InfiniteScrollService, VirtualScrollService, GridComponent } from '@syncfusion/ej2-angular-grids';

@Component({
  selector: 'app-root',
  standalone: true,
  providers: [PageService, SortService, ReorderService,LazyLoadGroupService,
    GroupService, InfiniteScrollService, VirtualScrollService],
  imports: [CommonModule, RouterOutlet, GridModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})


export class AppComponent {
   public data: Object[] | any;
   public pageSettings: Object | undefined;
   public options?: PageSettingsModel;
   public groupSettings: object = { enableLazyLoading: true , columns:['OrderID']};

   @ViewChild('grid')
    public grid: GridComponent | any;

    
    ngOnInit(): void {
        this.data = data;
        this.options= { pageCount: 50 };   
    }

    reorderColumns(): void {
      if (this.grid) {
        this.grid.reorderColumnByTargetIndex('OrderID',2);
      }
    }
}


