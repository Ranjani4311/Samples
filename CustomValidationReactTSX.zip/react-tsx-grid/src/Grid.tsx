import {
  GridComponent,
  ColumnsDirective,
  ColumnDirective,
  Inject,
  Toolbar,
  Edit,
  EditSettingsModel,
  EditEventArgs,
} from '@syncfusion/ej2-react-grids';
import { employeeDetails } from './data';

import { Query } from '@syncfusion/ej2-data';

declare global {
  interface Window {
    rowData: string | any;
  }
}

function DataGrid() {

  let grid : any;


  const toolbarOptions = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
  const editOptions: EditSettingsModel = { allowEditing: true, allowAdding: true, allowDeleting: true };

  const valChange = (args: any) => {
    // When the value of the TestResult dropdown changes, update the window.TestResult
    window.rowData.TestResult = args.value.toString(); // Explicitly cast args.value to string
    const formObj = grid.editModule.formObj.element['ej2_instances'][0];

    // Re-validate the EvidenceLink column when the TestResult value changes
   if(args.value == 'NOT OK'){
    formObj.rules['EvidenceLink']['required'][1] = 'Please enter Evidence Link ';
    formObj.validate()  //you can use this to trigger the validation simaultaneously when you select the value instead of focus out
   }
   else{
    formObj.validate()
   }
    
  };


  const testResultParams = {
    params: {
      allowFiltering: true,
      dataSource: ['OK','NOT OK'],
      query: new Query(),
      fields: { value: 'TestResult', text: 'TestResult' },
      change: valChange
    }
  };


  const customFn = (args: any): boolean => {
    // Custom validation logic for EvidenceLink column based on TestResult
    if (window.rowData.TestResult === 'NOT OK' && !args.value) {
      return false // Return false (invalid) if EvidenceLink is empty
    }
    return true; // If TestResult is "Ok", no validation needed 
  };

  const create = (): void => {
    if (grid) {
      let column = (grid as GridComponent).getColumnByField('EvidenceLink');
      column.validationRules = {
        required: [customFn, 'Required'],
      }
    }
  }
  const actionBegin = (args: EditEventArgs) => {
    window.rowData = args.rowData;
  }


  return  (<div>
    <GridComponent id='grid' ref={g => grid = g} dataSource={employeeDetails} editSettings={editOptions}
      toolbar={toolbarOptions} created={create} actionBegin={actionBegin}>
      <ColumnsDirective>
        <ColumnDirective field='EmployeeID' headerText='Employee ID' width='120' textAlign="Right" isPrimaryKey={true} />
        <ColumnDirective field='TestResult' headerText='TestResult' width='160' editType='dropdownedit' edit={testResultParams} />
        <ColumnDirective field='EvidenceLink' headerText='EvidenceLink' width='160'/>
        <ColumnDirective field='Address' headerText='Address' width='160' />
      </ColumnsDirective>
      <Inject services={[Edit, Toolbar]} />
    </GridComponent></div>);
}

export default DataGrid
